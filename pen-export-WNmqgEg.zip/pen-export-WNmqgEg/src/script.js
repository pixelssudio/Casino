function openDepositWindow() {
  document.getElementById('depositModal').style.display = 'block';
}

function closeDepositWindow() {
  document.getElementById('depositModal').style.display = 'none';
}

function openPaymentWindow(amount) {
  closeDepositWindow();
  // Simulate payment process
  setTimeout(function() {
    document.getElementById('paymentSuccess').style.display = 'block';
  }, 2000); // Simulating a delay of 2 seconds
}

document.addEventListener('keydown', function(event) {
  if (event.key === 'Backspace') {
    event.preventDefault(); // Prevent going back in browser history
    document.getElementById('paymentSuccess').style.display = 'none'; // Hide payment success message
    document.getElementById('depositModal').style.display = 'block'; // Show deposit modal again
  }
});

const reelsElement = document.getElementById('reels');
const balanceElement = document.getElementById('balance');
const betAmountElement = document.getElementById('betAmount');
const resultMessageElement = document.getElementById('result-message');

let balance = 100;

function placeBet() {
    const betAmount = parseInt(betAmountElement.value);

    if (isNaN(betAmount) || betAmount <= 0 || betAmount > balance) {
        alert('Invalid bet amount');
        return;
    }

    // Deduct the bet amount from the balance
    balance -= betAmount;
    updateBalance();

    // Spin the reels
    spinReels();
}

function spinReels() {
    // Clear existing symbols
    reelsElement.innerHTML = '';

    // Generate random symbols for each reel
    const symbols = ['🍒', '🍋', '🍇', '🍊', '🍉', '🍎'];
    const result = [];
    for (let i = 0; i < 3; i++) {
        const symbol = symbols[Math.floor(Math.random() * symbols.length)];
        const reelSymbol = document.createElement('div');
        reelSymbol.className = 'reel-symbol';
        reelSymbol.textContent = symbol;
        reelsElement.appendChild(reelSymbol);
        result.push(symbol);
    }

    // Check the result and update the balance accordingly
    checkResult(result);
}

function checkResult(result) {
    // Add your win/loss checking logic here
    const winAmount = calculateWin(result);
    if (winAmount > 0) {
        balance += winAmount;
        resultMessageElement.textContent = `You won $${winAmount}!`;
    } else {
        resultMessageElement.textContent = 'Sorry, you lost. Try again!';
    }

    // Update the balance and reset the input field
    updateBalance();
    betAmountElement.value = '';
}

function calculateWin(result) {
    // Add your win calculation logic based on the result here
    // For simplicity, let's say you win if all symbols are the same
    if (result[0] === result[1] && result[1] === result[2]) {
        return 2 * parseInt(betAmountElement.value); // Win 2 times the bet amount
    }
    return 0; // No win
}

function updateBalance() {
    balanceElement.textContent = `Balance: $${balance}`;
}
